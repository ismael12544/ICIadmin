<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />

        <!-- UIkit CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.9.2/dist/css/uikit.min.css" />

        <!-- UIkit JS -->
        <script src="https://cdn.jsdelivr.net/npm/uikit@3.9.2/dist/js/uikit.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/uikit@3.9.2/dist/js/uikit-icons.min.js"></script>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <title>Document</title>

        <!--     Fonts and icons     -->
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />

        <!-- Nucleo Icons -->
        <link href="<?php echo e(asset('css/nucleo-icons.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('css/nucleo-svg.css')); ?>" rel="stylesheet" />

        <!-- Font Awesome Icons -->
        <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>

        <!-- Material Icons -->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet" />

        <!-- CSS Files -->

        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />

        <!--=============== BOXICONS ===============-->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css" />

        <link id="pagestyle" href="<?php echo e(asset('css/material-kit.css?v=3.0.0')); ?>" rel="stylesheet" />
    </head>
    <body>
        <!-- Navbar -->
        <div class="container position-sticky z-index-sticky top-0">
            <div class="row">
                <div class="col-12">
                    <nav class="navbar navbar-expand-lg blur border-radius-xl top-0 z-index-fixed shadow position-absolute my-3 py-2 start-0 end-0 mx-4">
                        <div class="container-fluid px-0">
                            <a class="navbar-brand font-weight-bolder ms-sm-3" href="index.html" rel="tooltip" title="Designed and Coded by Creative Tim" data-placement="bottom" target="_blank">
                                <img src="<?php echo e(asset('img/ICILOGO2.png')); ?>" alt="Logo" width="70" height="70" />
                            </a>
                            <button class="navbar-toggler shadow-none ms-2" type="button" data-bs-toggle="collapse" data-bs-target="#navigation" aria-controls="navigation" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon mt-2">
                                    <span class="navbar-toggler-bar bar1"></span>
                                    <span class="navbar-toggler-bar bar2"></span>
                                    <span class="navbar-toggler-bar bar3"></span>
                                </span>
                            </button>
                            <div class="collapse navbar-collapse pt-3 pb-2 py-lg-0 w-100" id="navigation">
                                <ul class="navbar-nav navbar-nav-hover ms-auto">
                                    <li class="nav-item dropdown dropdown-hover mx-2">
                                        <a class="nav-link ps-2 d-flex cursor-pointer align-items-center" id="dropdownMenuPages" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="material-icons opacity-6 me-2 text-md">dashboard</i>
                                            Inicio
                                            <img src="<?php echo e(asset('img/down-arrow-dark.svg')); ?>" alt="down-arrow" class="arrow ms-auto ms-md-2" />
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-animation ms-n3 dropdown-md p-3 border-radius-xl mt-0 mt-lg-3" aria-labelledby="dropdownMenuPages">
                                            <div class="d-none d-lg-block">
                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex align-items-center px-1">
                                                    Landing Pages
                                                </h6>
                                                <a href="./pages/about-us.html" class="dropdown-item border-radius-md">
                                                    <span>About Us</span>
                                                </a>
                                                <a href="./pages/contact-us.html" class="dropdown-item border-radius-md">
                                                    <span>Contact Us</span>
                                                </a>
                                                <a href="./pages/author.html" class="dropdown-item border-radius-md">
                                                    <span>Author</span>
                                                </a>
                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex align-items-center px-1 mt-3">
                                                    Account
                                                </h6>
                                                <a href="./pages/sign-in.html" class="dropdown-item border-radius-md">
                                                    <span>Sign In</span>
                                                </a>
                                            </div>

                                            <div class="d-lg-none">
                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex align-items-center px-1">
                                                    Landing Pages
                                                </h6>

                                                <a href="./pages/about-us.html" class="dropdown-item border-radius-md">
                                                    <span>About Us</span>
                                                </a>
                                                <a href="./pages/contact-us.html" class="dropdown-item border-radius-md">
                                                    <span>Contact Us</span>
                                                </a>
                                                <a href="./pages/author.html" class="dropdown-item border-radius-md">
                                                    <span>Author</span>
                                                </a>

                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex align-items-center px-1 mt-3">
                                                    Account
                                                </h6>
                                                <a href="./pages/sign-in.html" class="dropdown-item border-radius-md">
                                                    <span>Sign In</span>
                                                </a>
                                            </div>
                                        </div>
                                    </li>

                                    <li class="nav-item dropdown dropdown-hover mx-2">
                                        <a class="nav-link ps-2 d-flex cursor-pointer align-items-center" id="dropdownMenuBlocks" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="material-icons opacity-6 me-2 text-md">view_day</i>
                                            Servicios
                                            <img src="<?php echo e(asset('img/down-arrow-dark.svg')); ?>" alt="down-arrow" class="arrow ms-auto ms-md-2" />
                                        </a>
                                        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-animation dropdown-md dropdown-md-responsive p-3 border-radius-lg mt-0 mt-lg-3" aria-labelledby="dropdownMenuBlocks">
                                            <div class="d-none d-lg-block">
                                                <li class="nav-item dropdown dropdown-hover dropdown-subitem">
                                                    <a class="dropdown-item py-2 ps-3 border-radius-md" href="./presentation.html">
                                                        <div class="w-100 d-flex align-items-center justify-content-between">
                                                            <div>
                                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Page Sections</h6>
                                                                <span class="text-sm">See all sections</span>
                                                            </div>
                                                            <img src="<?php echo e(asset('img/down-arrow-dark.svg')); ?>" alt="down-arrow" class="arrow ms-auto ms-md-2" />
                                                        </div>
                                                    </a>
                                                    <div class="dropdown-menu mt-0 py-3 px-2 mt-3">
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/page-sections/hero-sections.html">
                                                            Page Headers
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/page-sections/features.html">
                                                            Features
                                                        </a>
                                                    </div>
                                                </li>

                                                <li class="nav-item dropdown dropdown-hover dropdown-subitem">
                                                    <a class="dropdown-item py-2 ps-3 border-radius-md" href="./presentation.html">
                                                        <div class="w-100 d-flex align-items-center justify-content-between">
                                                            <div>
                                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Navigation</h6>
                                                                <span class="text-sm">See all navigations</span>
                                                            </div>
                                                            <img src="<?php echo e(asset('img/down-arrow-dark.svg')); ?>" alt="down-arrow" class="arrow ms-auto ms-md-2" />
                                                        </div>
                                                    </a>
                                                    <div class="dropdown-menu mt-0 py-3 px-2 mt-3">
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/navigation/navbars.html">
                                                            Navbars
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/navigation/nav-tabs.html">
                                                            Nav Tabs
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/navigation/pagination.html">
                                                            Pagination
                                                        </a>
                                                    </div>
                                                </li>

                                                <li class="nav-item dropdown dropdown-hover dropdown-subitem">
                                                    <a class="dropdown-item py-2 ps-3 border-radius-md" href="./presentation.html">
                                                        <div class="w-100 d-flex align-items-center justify-content-between">
                                                            <div>
                                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Input Areas</h6>
                                                                <span class="text-sm">See all input areas</span>
                                                            </div>
                                                            <img src="<?php echo e(asset('img/down-arrow-dark.svg')); ?>" alt="down-arrow" class="arrow ms-auto ms-md-2" />
                                                        </div>
                                                    </a>
                                                    <div class="dropdown-menu mt-0 py-3 px-2 mt-3">
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/input-areas/inputs.html">
                                                            Inputs
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/input-areas/forms.html">
                                                            Forms
                                                        </a>
                                                    </div>
                                                </li>

                                                <li class="nav-item dropdown dropdown-hover dropdown-subitem">
                                                    <a class="dropdown-item py-2 ps-3 border-radius-md" href="./presentation.html">
                                                        <div class="w-100 d-flex align-items-center justify-content-between">
                                                            <div>
                                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Attention Catchers</h6>
                                                                <span class="text-sm">See all examples</span>
                                                            </div>
                                                            <img src="<?php echo e(asset('img/down-arrow-dark.svg')); ?>" alt="down-arrow" class="arrow ms-auto ms-md-2" />
                                                        </div>
                                                    </a>
                                                    <div class="dropdown-menu mt-0 py-3 px-2 mt-3">
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/attention-catchers/alerts.html">
                                                            Alerts
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/attention-catchers/modals.html">
                                                            Modals
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/attention-catchers/tooltips-popovers.html">
                                                            Tooltips & Popovers
                                                        </a>
                                                    </div>
                                                </li>

                                                <li class="nav-item dropdown dropdown-hover dropdown-subitem">
                                                    <a class="dropdown-item py-2 ps-3 border-radius-md" href="./presentation.html">
                                                        <div class="w-100 d-flex align-items-center justify-content-between">
                                                            <div>
                                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Elements</h6>
                                                                <span class="text-sm">See all elements</span>
                                                            </div>

                                                            <img src="<?php echo e(asset('img/down-arrow-dark.svg')); ?>" alt="down-arrow" class="arrow ms-auto ms-md-2" />
                                                        </div>
                                                    </a>
                                                    <div class="dropdown-menu mt-0 py-3 px-2 mt-3">
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/avatars.html">
                                                            Avatars
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/badges.html">
                                                            Badges
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/breadcrumbs.html">
                                                            Breadcrumbs
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/buttons.html">
                                                            Buttons
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/dropdowns.html">
                                                            Dropdowns
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/progress-bars.html">
                                                            Progress Bars
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/toggles.html">
                                                            Toggles
                                                        </a>
                                                        <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/typography.html">
                                                            Typography
                                                        </a>
                                                    </div>
                                                </li>
                                            </div>

                                            <div class="row d-lg-none">
                                                <div class="col-md-12">
                                                    <div class="d-flex mb-2">
                                                        <div class="icon h-10 me-3 d-flex mt-1">
                                                            <i class="ni ni-single-copy-04 text-gradient text-primary"></i>
                                                        </div>
                                                        <div class="w-100 d-flex align-items-center justify-content-between">
                                                            <div>
                                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Page Sections</h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/page-sections/hero-sections.html">
                                                        Page Headers
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/page-sections/features.html">
                                                        Features
                                                    </a>

                                                    <div class="d-flex mb-2 mt-3">
                                                        <div class="icon h-10 me-3 d-flex mt-1">
                                                            <i class="ni ni-laptop text-gradient text-primary"></i>
                                                        </div>
                                                        <div class="w-100 d-flex align-items-center justify-content-between">
                                                            <div>
                                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Navigation</h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/navigation/navbars.html">
                                                        Navbars
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/navigation/nav-tabs.html">
                                                        Nav Tabs
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/navigation/pagination.html">
                                                        Pagination
                                                    </a>

                                                    <div class="d-flex mb-2 mt-3">
                                                        <div class="icon h-10 me-3 d-flex mt-1">
                                                            <i class="ni ni-badge text-gradient text-primary"></i>
                                                        </div>
                                                        <div class="w-100 d-flex align-items-center justify-content-between">
                                                            <div>
                                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Input Areas</h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/input-areas/inputs.html">
                                                        Inputs
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/input-areas/forms.html">
                                                        Forms
                                                    </a>

                                                    <div class="d-flex mb-2 mt-3">
                                                        <div class="icon h-10 me-3 d-flex mt-1">
                                                            <i class="ni ni-notification-70 text-gradient text-primary"></i>
                                                        </div>
                                                        <div class="w-100 d-flex align-items-center justify-content-between">
                                                            <div>
                                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Attention Catchers</h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/attention-catchers/alerts.html">
                                                        Alerts
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/attention-catchers/modals.html">
                                                        Modals
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/attention-catchers/tooltips-popovers.html">
                                                        Tooltips & Popovers
                                                    </a>

                                                    <div class="d-flex mb-2 mt-3">
                                                        <div class="icon h-10 me-3 d-flex mt-1">
                                                            <i class="ni ni-app text-gradient text-primary"></i>
                                                        </div>
                                                        <div class="w-100 d-flex align-items-center justify-content-between">
                                                            <div>
                                                                <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Elements</h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/avatars.html">
                                                        Avatars
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/badges.html">
                                                        Badges
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/breadcrumbs.html">
                                                        Breadcrumbs
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/buttons.html">
                                                        Buttons
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/dropdowns.html">
                                                        Dropdowns
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/progress-bars.html">
                                                        Progress Bars
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/toggles.html">
                                                        Toggles
                                                    </a>
                                                    <a class="dropdown-item ps-3 border-radius-md mb-1" href="./sections/elements/typography.html">
                                                        Typography
                                                    </a>
                                                </div>
                                            </div>
                                        </ul>
                                    </li>

                                    <li class="nav-item dropdown dropdown-hover mx-2">
                                        <a class="nav-link ps-2 d-flex cursor-pointer align-items-center" id="dropdownMenuDocs" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="material-icons opacity-6 me-2 text-md">article</i>
                                            Productos
                                            <img src="<?php echo e(asset('img/down-arrow-dark.svg')); ?>" alt="down-arrow" class="arrow ms-auto ms-md-2" />
                                        </a>
                                        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-animation dropdown-md dropdown-md-responsive mt-0 mt-lg-3 p-3 border-radius-lg" aria-labelledby="dropdownMenuDocs">
                                            <div class="d-none d-lg-block">
                                                <ul class="list-group">
                                                    <li class="nav-item list-group-item border-0 p-0">
                                                        <a class="dropdown-item py-2 ps-3 border-radius-md" href=" https://www.creative-tim.com/learning-lab/bootstrap/overview/material-kit ">
                                                            <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Getting Started</h6>
                                                            <span class="text-sm">All about overview, quick start, license and contents</span>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item list-group-item border-0 p-0">
                                                        <a class="dropdown-item py-2 ps-3 border-radius-md" href=" https://www.creative-tim.com/learning-lab/bootstrap/colors/material-kit ">
                                                            <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Foundation</h6>
                                                            <span class="text-sm">See our colors, icons and typography</span>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item list-group-item border-0 p-0">
                                                        <a class="dropdown-item py-2 ps-3 border-radius-md" href=" https://www.creative-tim.com/learning-lab/bootstrap/alerts/material-kit ">
                                                            <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Components</h6>
                                                            <span class="text-sm">Explore our collection of fully designed components</span>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item list-group-item border-0 p-0">
                                                        <a class="dropdown-item py-2 ps-3 border-radius-md" href=" https://www.creative-tim.com/learning-lab/bootstrap/datepicker/material-kit ">
                                                            <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Plugins</h6>
                                                            <span class="text-sm">Check how you can integrate our plugins</span>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item list-group-item border-0 p-0">
                                                        <a class="dropdown-item py-2 ps-3 border-radius-md" href=" https://www.creative-tim.com/learning-lab/bootstrap/utilities/material-kit ">
                                                            <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Utility Classes</h6>
                                                            <span class="text-sm">For those who want flexibility, use our utility classes</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>

                                            <div class="row d-lg-none">
                                                <div class="col-md-12 g-0">
                                                    <a class="dropdown-item py-2 ps-3 border-radius-md" href="./pages/about-us.html">
                                                        <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Getting Started</h6>
                                                        <span class="text-sm">All about overview, quick start, license and contents</span>
                                                    </a>

                                                    <a class="dropdown-item py-2 ps-3 border-radius-md" href="./pages/about-us.html">
                                                        <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Foundation</h6>
                                                        <span class="text-sm">See our colors, icons and typography</span>
                                                    </a>

                                                    <a class="dropdown-item py-2 ps-3 border-radius-md" href="./pages/about-us.html">
                                                        <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Components</h6>
                                                        <span class="text-sm">Explore our collection of fully designed components</span>
                                                    </a>

                                                    <a class="dropdown-item py-2 ps-3 border-radius-md" href="./pages/about-us.html">
                                                        <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Plugins</h6>
                                                        <span class="text-sm">Check how you can integrate our plugins</span>
                                                    </a>

                                                    <a class="dropdown-item py-2 ps-3 border-radius-md" href="./pages/about-us.html">
                                                        <h6 class="dropdown-header text-dark font-weight-bolder d-flex justify-content-cente align-items-center p-0">Utility Classes</h6>
                                                        <span class="text-sm">For those who want flexibility, use our utility classes</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                    <!-- End Navbar -->
                </div>
            </div>
        </div>

        <!--  Header -->
        <header>
            <div class="page-header min-vh-100" style="background-image: url(&#39;https://kuzudecoletaje.es/wp-content/uploads/2019/05/Linea_de_Inspeccion_Automatizada.jpg&#39;);" loading="lazy">
                <span class="mask bg-gradient-dark opacity-5"></span>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 d-flex justify-content-center flex-column">
                            <h1 class="text-white text-center" id="t-empresa">ICI</h1>
                            <p class="text-white text-center opacity-8 lead" id="t-empresa2">Imagina crea ingeniería</p>

                            <button type="button" class="btn btn-white" id="boton-start">Get Started</button>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- End Header -->

        <!-- Card Mision, Vison, Enfoque -->

        <div class="card card-body blur shadow-blur mx-3 mx-md-4 mt-n6">
            <section class="my-5 py-5">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-4 ms-auto me-auto p-lg-4 mt-lg-0 mt-4">
                            <div class="rotating-card-container">
                                <div class="card card-rotate card-background mt-md-0 mt-5">
                                    <div
                                        class="front front-background"
                                        style="
                                            background-image: url(https://images.unsplash.com/photo-1569683795645-b62e50fbf103?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80);
                                            background-size: cover;
                                        "
                                    >
                                        <div class="card-body py-7 text-center">
                                            <h3 class="text-white" id="t-ici">ICI</h3>
                                            <p class="text-white opacity-8">
                                                Las opciones que mostramos dan una visión asertiva a la problemática que surgen en las empresas, acorde a sus necesidades e ideales basados en el profesionalismo y la amplia experiencia de
                                                nuestro equipo
                                            </p>
                                        </div>
                                    </div>
                                    <div
                                        class="back back-background"
                                        style="
                                            background-image: url(https://images.unsplash.com/photo-1498889444388-e67ea62c464b?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1365&q=80);
                                            background-size: cover;
                                        "
                                    >
                                        <div class="card-body pt-7 text-center">
                                            <h3 class="text-white">Discover More</h3>
                                            <p class="text-white opacity-8">You will save a lot of time going from prototyping to full-functional code because all elements are implemented.</p>
                                            <a href=".//sections/page-sections/hero-sections.html" target="_blank" class="btn btn-white btn-sm w-50 mx-auto mt-3">Start with Headers</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 ms-auto">
                            <div class="row justify-content-start">
                                <div class="col-md-6">
                                    <div class="info">
                                        <h5 class="font-weight-bolder mt-3">Misión</h5>
                                        <p class="pe-5" style="text-align: justify; -moz-text-align-last: center; text-align-last: center;">
                                            Enfocados a las pequeñas, medianas y grandes empresas para ayudarlas a crecer al siguiente nivel en automatización y producción, creando soluciones dentro de sus posibilidades y seguir creciendo
                                            en conjunto como empresa con vista hacia el futuro.
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="info">
                                        <h5 class="font-weight-bolder mt-3">Enfoque</h5>
                                        <p class="pe-3" style="text-align: justify; -moz-text-align-last: center; text-align-last: center;">
                                            Creación de soluciones efectivas dando resultados óptimos a las necesidades y resolviendo las dificultades que retrasan la producción que tienen un impacto significativo en el producto final.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="row justify-content-start mt-5">
                                <div class="col-md-6 mt-3">
                                    <h5 class="font-weight-bolder mt-3">Visión</h5>
                                    <p class="pe-5" style="text-align: justify; -moz-text-align-last: center; text-align-last: center;">
                                        Crecimiento mutuo entre las empresas tanto personal como profesional, logrando posicionarnos entre los mejores, creando una alianza llena de confianza.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <!-- End Card Mision, Vison, Enfoque -->

        <div class="container mt-sm-5 mt-5" id="servicios">
            <div class="row">
                <div class="col-lg-12  shadow rounded rounded-lg text-center">
                    
                       <p class="text-center"><h3 id="t-servicios">Servicios</h3></p>
                       
                  
                </div>

                <div class="container">
                    <div class="card">
                        <div class="card-header">
                            <ul class="nav nav-tabs  shadow rounded justify-content-center" role="tablist">
                                <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item" title="<?php echo e($s->descripcion); ?>">
                                    <a class="nav-link" data-toggle="tab" href="#<?php echo e($s->nombre); ?>" role="tab" id="ser-list">
                                        <?php echo e($s->nombre); ?>

                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="card-body">
                            <div class="tab-content ">
                                <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane " id="<?php echo e($s->nombre); ?>" role="tabpanel">
                                   
                                        <div class="container">
                                            <div class="row align-items-center">
                                                <div class="col-lg-6 border ">
                                                 <p class="text-center"><strong><?php echo e($s->nombre); ?></strong></p> 
                                                
                                            
                                                <section class="accordion  container mt-sm-5 mt-5">
                                                    <div class="accordion__container">
                                                    <?php $__currentLoopData = $s->soport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $so): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="accordion__item">
                                                            <header class="accordion__header">
                                                                <i class='bx bx-chevron-down accordion__icon'></i>
                                                                <h3 class="accordion__title text-light"><?php echo e($so->nombre); ?></h3>
                                                            </header>

                                                            <div class="accordion__content">
                                                                <p class="accordion__description">
                                                                   <?php echo e($so->descripcion); ?>

                                                                </p>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </section>
                                                
                                                 <button class="btn bg-gradient btn-info">Solicitar servicio</buttom>
                                                </div>

                                                <div class="col-lg-6 shadow-lg ms-auto me-auto p-lg-4 mt-lg-0 mt-4">
                                                    <div class="accordion__container">
                                                        <img
                                                            src="https://images.unsplash.com/photo-1593106410245-241ab38175e7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
                                                            alt="#"
                                                            class="img-responsive"
                                                            alt="Responsive image"
                                                            width=""
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                   
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script type="text/javascript">
            /*=============== ACCORDION ===============*/
            const accordionItems = document.querySelectorAll(".accordion__item");

            // 1. Selecionar cada item
            accordionItems.forEach((item) => {
                const accordionHeader = item.querySelector(".accordion__header");

                // 2. Seleccionar cada click del header
                accordionHeader.addEventListener("click", () => {
                    // 7. Crear la variable
                    const openItem = document.querySelector(".accordion-open");

                    // 5. Llamar a la funcion toggle item
                    toggleItem(item);

                    // 8. Validar si existe la clase
                    if (openItem && openItem !== item) {
                        toggleItem(openItem);
                    }
                });
            });

            // 3. Crear una funcion tipo constante
            const toggleItem = (item) => {
                // 3.1 Crear la variable
                const accordionContent = item.querySelector(".accordion__content");

                // 6. Si existe otro elemento que contenga la clase accorion-open que remueva su clase
                if (item.classList.contains("accordion-open")) {
                    accordionContent.removeAttribute("style");
                    item.classList.remove("accordion-open");
                } else {
                    // 4. Agregar el height maximo del content
                    accordionContent.style.height = accordionContent.scrollHeight + "px";
                    item.classList.add("accordion-open");
                }
            };
        </script>

        <!--   Core JS Files   -->
        <script src="<?php echo e(asset('js/core/popper.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/core/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/plugins/perfect-scrollbar.min.js')); ?>"></script>

        <!--  Plugin for TypedJS, full documentation here: https://github.com/inorganik/CountUp.js -->
        <script src="<?php echo e(asset('js/plugins/countup.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/plugins/choices.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/plugins/prism.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/plugins/highlight.min.js')); ?>"></script>

        <!--  Plugin for Parallax, full documentation here: https://github.com/dixonandmoe/rellax -->
        <script src="<?php echo e(asset('js/plugins/rellax.min.js')); ?>"></script>
        <!--  Plugin for TiltJS, full documentation here: https://gijsroge.github.io/tilt.js/ -->
        <script src="<?php echo e(asset('js/plugins/tilt.min.js')); ?>"></script>
        <!--  Plugin for Selectpicker - ChoicesJS, full documentation here: https://github.com/jshjohnson/Choices -->
        <script src="<?php echo e(asset('js/plugins/choices.min.js')); ?>"></script>

        <!--  Plugin for Parallax, full documentation here: https://github.com/wagerfield/parallax  -->
        <script src="<?php echo e(asset('js/plugins/parallax.min.js')); ?>"></script>

        <!-- Control Center for Material UI Kit: parallax effects, scripts for the example pages etc -->
        <!--  Google Maps Plugin    -->

        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDTTfWur0PDbZWPr7Pmq8K3jiDp0_xUziI"></script>
        <script src="./assets/js/material-kit.min.js?v=3.0.0" type="text/javascript"></script>
    </body>
</html>
<?php /**PATH C:\Users\Usuario\Downloads\Nueva carpeta\resources\views/welcome.blade.php ENDPATH**/ ?>