<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="./assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        ICI
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
        name='viewport' />
    <!--     Fonts and icons     -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <!-- CSS Files -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/now-ui-kit.css')); ?>" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="<?php echo e(asset('demo/demo.css')); ?>" rel="stylesheet" />




</head>

<body class="index-page sidebar-collapse">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-dark fixed-top navbar-transparent " color-on-scroll="400">
        <div class="container">
            <div class="navbar-translate">
                <p class="bg-light rouded"><img src="<?php echo e(asset('img/logo3.png')); ?>" width="124" height="70" alt=""></p>

                <button class="navbar-toggler navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navigation" aria-controls="navigation-index" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-bar top-bar"></span>
                    <span class="navbar-toggler-bar middle-bar"></span>
                    <span class="navbar-toggler-bar bottom-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse justify-content-end" id="navigation"
                data-nav-image="./assets/img/blurred-image-1.jpg">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="javascript:void(0)" onclick="scrollToDownload()">
                            <i class="fas fa-sms mr-1" style="font-size:20px;"></i>
                            <p>Contacto</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="javascript:void(0)" onclick="scrollToDownload()">
                            <i class="fas fa-users mr-1" style="font-size:20px;"></i>
                            <p>¿Porque confiar en notros?</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="javascript:void(0)" onclick="scrollToDownload()">
                            <i class="fas fa-project-diagram mr-1" style="font-size:20px;"></i>
                            <p>Proyectos</p>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" id="navbarDropdownMenuLink1"
                            data-toggle="dropdown">
                            <i class="fas fa-cogs mr-1" style="font-size:20px;"></i>
                            <p>Soporte y Servicios</p>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink1">
                            <a class="dropdown-item" href="./index.html">
                                <i class="now-ui-icons business_chart-pie-36"></i> Mantenimientos
                            </a>
                            <a class="dropdown-item" target="_blank" href="
https://demos.creative-tim.com/now-ui-kit/docs/1.0/getting-started/introduction.html
">
                                <i class="now-ui-icons design_bullet-list-67"></i> Programación
                            </a>
                            <a class="dropdown-item" target="_blank" href="
https://demos.creative-tim.com/now-ui-kit/docs/1.0/getting-started/introduction.html
">
                                <i class="now-ui-icons design_bullet-list-67"></i> Refacciones
                            </a>
                            <a class="dropdown-item" target="_blank" href="
https://demos.creative-tim.com/now-ui-kit/docs/1.0/getting-started/introduction.html
">
                                <i class="now-ui-icons design_bullet-list-67"></i> Transportadores
                            </a>
                            <a class="dropdown-item" target="_blank" href="
https://demos.creative-tim.com/now-ui-kit/docs/1.0/getting-started/introduction.html
">
                                <i class="now-ui-icons design_bullet-list-67"></i> Ensambles
                            </a>
                            <a class="dropdown-item" target="_blank" href="
https://demos.creative-tim.com/now-ui-kit/docs/1.0/getting-started/introduction.html
">
                                <i class="now-ui-icons design_bullet-list-67"></i> Instalaciones
                            </a>
                            <a class="dropdown-item" target="_blank" href="
https://demos.creative-tim.com/now-ui-kit/docs/1.0/getting-started/introduction.html
">
                                <i class="now-ui-icons design_bullet-list-67"></i> Maquinados
                            </a>
                            <a class="dropdown-item" target="_blank" href="
https://demos.creative-tim.com/now-ui-kit/docs/1.0/getting-started/introduction.html
">
                                <i class="now-ui-icons design_bullet-list-67"></i> Etiquetadoras
                            </a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="javascript:void(0)" onclick="scrollToDownload()">
                            <i class="fas fa-home" style="font-size:20px;"></i>
                            <p>Inicio</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" rel="tooltip" title="Follow us on Twitter" data-placement="bottom" href="
https://twitter.com/CreativeTim
" target="_blank">
                            <i class="fab fa-twitter"></i>
                            <p class="d-lg-none d-xl-none">Twitter</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" rel="tooltip" title="Like us on Facebook" data-placement="bottom" href="
https://www.facebook.com/CreativeTim
" target="_blank">
                            <i class="fab fa-facebook-square"></i>
                            <p class="d-lg-none d-xl-none">Facebook</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" rel="tooltip" title="Follow us on Instagram" data-placement="bottom" href="
https://www.instagram.com/CreativeTimOfficial
" target="_blank">
                            <i class="fab fa-instagram"></i>
                            <p class="d-lg-none d-xl-none">Instagram</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav> <!-- End Navbar -->
    <div class="wrapper">

        <div class="page-header clear-filter" filter-color="blue">
            <div class="page-header-image" data-parallax="true"
                style="background-image:url('https://vestertraining.com/wp-content/uploads/2019/07/Automatizacion-industrial.jpg');">
            </div>

            <div class="container">
                <div class="content-center brand">
                    <div class="container-fluid  text-center position-relative">
                        <p id="texto" style="" class="animacion-1">Soluciones en automatización </p>
                        <p class="rounded animacion-2" id="texto2" style="">Creación de soluciones efectivas dando
                            resultados óptimos</p>
                    </div>

                </div>

            </div>
        </div>

        <div class="section container">
            <div class="container-fluid  text-center position-relative">
                <h3 class="text-muted" id="empresa2" style="font-size:25px;">
                    Nuestra Empresa
                </h3>

                <div class="row">
                    <div class="col-md-12">
                        <h1 id="empresa">ICI</h1>
                        <h2 id="empresa2">Imagina Crea Ingeniería</h2>
                    </div>
                    <div class="">
                        <div class="section">
                            <div class="container">
                                <div class="card">
                                    <div class="card-header">
                                        <ul class="nav nav-tabs justify-content-center" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active" data-toggle="tab" href="#home" role="tab">
                                                    <i class="fas fa-flag-checkered"></i> MISIÓN
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#profile" role="tab">
                                                    <i class="far fa-eye"></i> VISIÓN
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#messages" role="tab">
                                                    <i class="fas fa-search"></i> ENFOQUE
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="card-body">
                                        <!-- Tab panes -->
                                        <div class="tab-content text-center">
                                            <div class="tab-pane active" id="home" role="tabpanel">
                                                <p>Enfocados a las pequeñas, medianas y grandes empresas para
                                                    ayudarlas a crecer al
                                                    siguiente nivel en automatización y producción, creando
                                                    soluciones dentro de sus
                                                    posibilidades y seguir creciendo en conjunto como empresa con
                                                    vista hacia el
                                                    futuro.</p>
                                            </div>
                                            <div class="tab-pane" id="profile" role="tabpanel">
                                                <p> Crecimiento mutuo entre las empresas tanto personal como
                                                    profesional, logrando
                                                    posicionarnos entre los mejores, creando una alianza llena de
                                                    confianza </p>
                                            </div>
                                            <div class="tab-pane" id="messages" role="tabpanel">
                                                <p>Creación de soluciones efectivas dando resultados óptimos a las
                                                    necesidades y
                                                    resolviendo las dificultades que retrasan la producción que
                                                    tienen un impacto
                                                    significativo en el producto final.
                                                    Las opciones que mostramos dan una visión asertiva a la
                                                    problemática que surgen
                                                    en las empresas, acorde a sus necesidades e ideales basados en
                                                    el
                                                    profesionalismo y la amplia experiencia de nuestro equipo

                                                </p>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="  col-md-12 mt-5 border-top ">
                        <h1 class="text-muted mt-4" style="font-size:25px;" id="empresa2">Experiencia <i
                                class="fas fa-tools text-dark"></i></h1>
                    </div>

                    <div class="col-md-6 mt-5 ">

                        <div class="text-center">

                            <p class="text-dark category" style="font-size:12px;"> <i
                                    class="fas fa-check text-success mr-3"></i>Soporte y Servicio Técnico</p>
                            <p class="text-dark category" style="font-size:12px;"> <i
                                    class="fas fa-check text-success mr-3"></i>Fabricación de Etiquetadoras</p>
                            <p class="text-dark category" style="font-size:12px;"> <i
                                    class="fas fa-check text-success mr-3"></i>Fabricación de Transportadores</p>
                            <p class="text-dark category" style="font-size:12px;"> <i
                                    class="fas fa-check text-success mr-3"></i>Fabricación de Equipos Automatizados
                            </p>
                            <p class="text-dark category" style="font-size:12px;"> <i
                                    class="fas fa-check text-success mr-3"></i>Amplio Conocimiento en la Industria
                                Metal Mecánica</p>
                            <p class="text-dark category" style="font-size:12px;"> <i
                                    class="fas fa-check text-success mr-3"></i>Maquinados CNC y Convencionales</p>
                        </div>

                    </div>
                    <div class="col-md-6 mt-5 ">

                        <div class="text-center">
                            <h3 class="">

                                <p class="text-dark category" style="font-size:12px;"> <i
                                        class="fas fa-check text-success mr-3"></i>Creación de Soluciones</p>
                                <p class="text-dark category" style="font-size:12px;"> <i
                                        class="fas fa-check text-success mr-3"></i>Soluciones de Procesos y
                                    Producción</p>
                                <p class="text-dark category" style="font-size:12px;"> <i
                                        class="fas fa-check text-success mr-3"></i>Mantenimiento Especializado</p>
                                <p class="text-dark category" style="font-size:12px;"> <i
                                        class="fas fa-check text-success mr-3"></i>Modificación, Actualización de
                                    Equipos e Integraciones</p>
                                <p class="text-dark category" style="font-size:12px;"> <i
                                        class="fas fa-check text-success mr-3"></i>Control y Programación</p>
                                <p class="text-dark category" style="font-size:12px;"> <i
                                        class="fas fa-check text-success mr-3"></i>Refaccionamiento y mucho más…</p>

                            </h3>
                        </div>

                    </div>
                </div>
            </div>
        </div>


        <div class="py-10">
            <div class="container clients">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-12">
                        <div class="text-center mb-10">
                            <h3 class="text-muted" id="empresa2" style="font-size:25px;">
                                Nuestros Clientes
                            </h3>

                            <hr id="separador">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c1.png')); ?>" width="64">
                            </img>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c2.jpeg')); ?>" width="64">
                            </img>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c3.jpeg')); ?>" width="64">
                            </img>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c4.jpeg')); ?>" width="64">
                            </img>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c5.jpeg')); ?>" width="64">
                            </img>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c7.jpeg')); ?>" width="64">
                            </img>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c8.jpeg')); ?>" width="64">
                            </img>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c9.jpeg')); ?>" width="64">
                            </img>

                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c10.jpeg')); ?>" width="64">
                            </img>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c11.jpeg')); ?>" width="64">
                            </img>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c12.jpeg')); ?>" width="64">
                            </img>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c13.jpeg')); ?>" width="64">
                            </img>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-12">
                        <div class="mb-4 text-center">
                            <img alt="" class="bg-primary" height="64" src="<?php echo e(asset('img/c14.jpeg')); ?>" width="64">
                            </img>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">

            <h2>DESARROLLOS</h2>
            <hr>
            <div class="pull-right">
                <button class="btn btn-small bg-warning " data-toggle="portfilter" data-target="all" id="boton">
                    All
                </button>
                <button class="btn btn-small bg-warning " data-toggle="portfilter" data-target="trasnpostadores" id="boton">
                    TRANSPORTADORES
                </button>
                <button class="btn btn-small bg-warning " data-toggle="portfilter" data-target="maquinados" id="boton">
                    MAQUINADOS
                </button>
                <button class="btn btn-small bg-warning " data-toggle="portfilter" data-target="taponadoras" id="boton">
                    TAPONADORAS
                </button>
                <button class="btn btn-small bg-warning " data-toggle="portfilter" data-target="llenadoras" id="boton">
                    LLENADORAS
                </button>
                <button class="btn btn-small bg-warning " data-toggle="portfilter" data-target="mas" id="boton">
                    MAS
                </button>
            </div>
            <div class="clearfix"></div>

            <br>

            <div class="thumbnails gallery">
                <div class="row">
                    <div class="col-md-3" data-tag="etiquetadoras">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Manejamos equipos de línea como HERMA</h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="trasnpostadores">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Equipos de línea desde los mas comunes hasta los menos utilizados</h4>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="etiquetadoras">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Diseños especiales </h4>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="trasnpostadores">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Especiales </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="trasnpostadores">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Refacciones </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="etiquetadoras">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Adaptaciones </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 clearfix" data-tag="trasnpostadores">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Adaptaciones </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="trasnpostadores">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Integraciones</h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="etiquetadoras">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Integraciones</h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="maquinados">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Diseño y fabricación de piezas especiales</h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="maquinados">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>CNC</h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="maquinados">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Convencionales </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="maquinados">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Torno </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="maquinados">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Fresadora </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="taponadoras">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Diseños especiales </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="taponadoras">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Refacciones </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="taponadoras">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Adaptaciones </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="taponadoras">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Integraciones </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="llenadoras">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Diseños especiales </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="llenadoras">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Refacciones </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="llenadoras">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Adaptaciones </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="llenadoras">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Integraciones </h4>
                            </div>
                        </div>
                    </div>




                    <div class="col-md-3" data-tag="mas">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Diseño y fabricación de piezas especiales </h4>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-3" data-tag="mas">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Túneles de calor Túneles de calor </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="mas">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Lavadoras </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="mas">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Mesas de acumulación </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-tag="mas">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Codificadores </h4>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3" data-tag="mas">
                        <div class="thumbnail">

                            <div class="caption">
                                <h4>Refacciones y mas </h4>
                            </div>
                        </div>
                    </div>


                </div>

            </div>
            <div class="push"></div>
        </div>


        <section class="cta" id="cta">
                <div class="container">
                    <div class="text-center" data-aos="zoom-in">
                           <button type="button" class="btn btn-default btn-circle btn-xl"><i class="fa fa-check"></i>
                            </button>
                        <h3>
                            POR QUE CONFIAR EN NOSOTROS
                        </h3>
                        <p>
                           La mejor recomendación es la calidad de trabajo un trabajo bien hecho habla bien de todos, tenemos la experiencia, compromiso, satisfacción y entrega por hacer las cosas bien de la mejor manera posible, desde una preparación académica hasta la practica en campo con el equipo de expertos de cada área especializada.
                        </p>

                        <div class="row" id="apartado-nosotros">
                            <div class="col-md-2">
                            <p id="p-nosotros">Precios accesibles</p>
                            </div>
                            <div class="col-md-2">
                                <p id="p-nosotros">Metas alcanzables</p>

                            </div>
                            <div class="col-md-2">
                                <p id="p-nosotros"> Tiempo de entrega</p>

                            </div>
                            <div class="col-md-2">
                                <p id="p-nosotros">Experiencia</p>

                            </div>
                            <div class="col-md-2">
                                <p id="p-nosotros">Metas alcanzables</p>

                            </div>
                            <div class="col-md-2">
                                <p id="p-nosotros">  Soluciones claras</p>

                            </div>
                        </div>

                    </div>
                </div>
            </section>



        <footer class="footer" data-background-color="black">

            <div class="copyright" id="copyright">
                &copy;
                <script>
                document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
                </script>
            </div>

        </footer>
    </div>
    <!--   Core JS Files   -->

    <script src="<?php echo e(asset('js/core/jquery.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/core/popper.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/core/bootstrap.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/plugins/bootstrap-switch.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/plugins/bootstrap-datepicker.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/plugins/nouislider.min.js')); ?>" type="text/javascript"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.6.1/gsap.min.js"></script>
    <!-- Control Center for Now Ui Kit: parallax effects, scripts for the example pages etc -->
    <script src="<?php echo e(asset('js//now-ui-kit.js?v=1.3.0')); ?>" type="text/javascript"></script>


    <script>
    $(document).ready(function() {
        // the body of this function is in assets/js/now-ui-kit.js
        nowuiKit.initSliders();
    });

    function scrollToDownload() {

        if ($('.section-download').length != 0) {
            $("html, body").animate({
                scrollTop: $('.section-download').offset().top
            }, 1000);

        }
    }
    </script>

    <script>
    gsap.from('.animacion-1', {
        duration: 3,

        x: 150,
        //delay:1,
        ease: 'bounce.out',
    });


    gsap.from('.animacion-2', {
        duration: 3,
        scale: 1.5,
        y: 15,
        //delay:1,
        ease: 'bounce.out',
    });



    gsap.from('.animacion-logo', {
        duration: 3,
        scale: 2,
        y: 15,
        ease: "slow(0.1, 0.1, false)",
        y: -500,
    });


    ! function(d) {
        var c = "portfilter";
        var b = function(e) {
            this.$element = d(e);
            this.stuff = d("[data-tag]");
            this.target = this.$element.data("target") || ""
        };
        b.prototype.filter = function(g) {
            var e = [],
                f = this.target;
            this.stuff.fadeOut("fast").promise().done(function() {
                d(this).each(function() {
                    if (d(this).data("tag") == f || f == "all") {
                        e.push(this)
                    }
                });
                d(e).show()
            })
        };
        var a = d.fn[c];
        d.fn[c] = function(e) {
            return this.each(function() {
                var g = d(this),
                    f = g.data(c);
                if (!f) {
                    g.data(c, (f = new b(this)))
                }
                if (e == "filter") {
                    f.filter()
                }
            })
        };
        d.fn[c].defaults = {};
        d.fn[c].Constructor = b;
        d.fn[c].noConflict = function() {
            d.fn[c] = a;
            return this
        };
        d(document).on("click.portfilter.data-api", "[data-toggle^=portfilter]", function(f) {
            d(this).portfilter("filter")
        })
    }(window.jQuery);
    </script>
</body>

</html><?php /**PATH C:\Users\Usuario\Desktop\ICI (1)\ICI\resources\views/welcome.blade.php ENDPATH**/ ?>